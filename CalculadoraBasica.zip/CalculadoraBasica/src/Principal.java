
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author dsm-2
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Calculadora calc = new Calculadora();
        int op;
        double a, b;
        
        do{
            op = Integer.parseInt(JOptionPane.showInputDialog("Digite uma opção: \n 1 - Somar" + "\n 2 - Subtrair" + "\n 3 - Multiplicar" + " \n 4 - Dividir" + "\n 0 - Sair"));
            
            switch(op){
                case 1:
                    calc.Soma();
                break;
                case 2:
                    a = Double.parseDouble(JOptionPane.showInputDialog("Digite o primeiro valor: "));
                    b = Double.parseDouble(JOptionPane.showInputDialog("Digite o segundo valor: "));
                    calc.Subtrair(a, b);
                break; 
                case 3:
                    calc.Multiplicar();
                    JOptionPane.showMessageDialog(null, "O valor da multiplicação é: " + calc.getR());
                break;
                case 4:
                    a = Double.parseDouble(JOptionPane.showInputDialog("Digite o primeiro valor: "));
                    b = Double.parseDouble(JOptionPane.showInputDialog("Digite o segundo valor: "));
                    calc.Dividir(a, b);
                    JOptionPane.showMessageDialog(null, "O valor da multiplicação é: " + calc.getR());
                break;
                case 0:
                    JOptionPane.showMessageDialog(null, "Você decidiu sair.");
                break;
                default:
                    JOptionPane.showMessageDialog(null, "Opção inválida!");
                break;
            }
            
        }while(op != 0);
        
        
    }
    
}
